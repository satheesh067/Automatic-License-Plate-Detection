document.addEventListener('DOMContentLoaded', function () {
    const loginForm = document.getElementById('loginForm');

    loginForm.addEventListener('submit', function (e) {
        e.preventDefault();

        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;
        const role = document.getElementById('role').value;
        const remember = document.getElementById('remember').checked;

        if (!email || !password || !role) {
            showLoginError('Please fill in all fields');
            return;
        }

        fetch('http://127.0.0.1:5500/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ email, password, role }),
        })
        .then((response) => response.json())
        .then((data) => {
            if (data.status === 'success') {
                localStorage.setItem('userEmail', email);
                localStorage.setItem('userRole', role);
                if (remember) {
                    localStorage.setItem('rememberUser', 'true');
                }
                switch (role) {
                    case 'citizen':
                        window.location.href = '/flask/dashboard_user.html';
                        break;
                    case 'police':
                        window.location.href = 'dashboard_police.html';
                        break;
                    case 'admin':
                        window.location.href = 'dashboard_admin.html';
                        break;
                    default:
                        showLoginError('Unknown role');
                }
            } else {
                showLoginError(data.message || 'Login failed');
            }
        })
        .catch((error) => {
            console.error('Error:', error);
            showLoginError('Server error. Please try again later.');
        });
    });

    function showLoginError(message) {
        const modal = document.getElementById('loginErrorModal');
        const messageElement = document.getElementById('loginErrorText');
        messageElement.textContent = message;
        modal.style.display = 'block';
    }

    document.getElementById('closeErrorModal').addEventListener('click', () => {
        document.getElementById('loginErrorModal').style.display = 'none';
    });
});
